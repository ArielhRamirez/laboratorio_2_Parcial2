﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public static class ExtensoraRandom
    {
        public static Random random = new Random();
        public static int GenerarRandom(this List<Serie> lista) 
        { 
            return random.Next(0,lista.Count);
        }
    }
}
