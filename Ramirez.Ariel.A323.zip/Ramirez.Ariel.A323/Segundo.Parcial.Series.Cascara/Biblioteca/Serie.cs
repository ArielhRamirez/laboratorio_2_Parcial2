﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Serie
    {
        private string genero;
        private string nombre;

        public string Genero { get => genero; set => genero = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public Serie() 
        { 
        
        }

        public Serie(string genero, string nombre)
        {
            this.genero = genero;
            this.nombre = nombre;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Nombre: {nombre}");
            sb.AppendLine($"Genero: {genero}");
            return sb.ToString();
        }
    }
}
