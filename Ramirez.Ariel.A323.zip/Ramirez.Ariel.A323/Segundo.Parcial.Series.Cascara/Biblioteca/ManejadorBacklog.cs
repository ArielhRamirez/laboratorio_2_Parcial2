﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public delegate void DelegadoBacklog(Serie ciudadano);
    public class ManejadorBacklog
    {
        public event DelegadoBacklog SerieParaVer;
        public void IniciarManejador(List<Serie> series) 
        {
            Task hilo = Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series) 
        {
            while (series.Count > 0)
            {
                int random = series.GenerarRandom();
                AccesoDatos.ActualizarSerie(series[random]);
                Thread.Sleep(1500);
                if (SerieParaVer is not null) 
                {
                    SerieParaVer.Invoke(series[random]);
                }
            }
        }
    }
}
