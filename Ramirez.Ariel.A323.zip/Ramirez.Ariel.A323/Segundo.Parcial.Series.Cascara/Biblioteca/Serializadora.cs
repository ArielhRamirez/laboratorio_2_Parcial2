﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Biblioteca
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        public void Guardar(List<Serie> items, string ruta)
        {
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(ruta))
                {
                    foreach (Serie serie in items)
                    {
                        XmlSerializer xmlSerializer = new XmlSerializer(typeof(Serie));
                        xmlSerializer.Serialize(streamWriter, serie);
                    }
                }
            }
            catch (Exception e)
            {
                throw new BacklogException(e.Message);
            }
        }

        void IGuardar<List<Serie>>.Guardar(List<Serie> lista, string ruta)
        {
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(ruta))
                {
                    foreach (Serie serie in lista)
                    {
                        string jsonString = JsonSerializer.Serialize(serie);
                        streamWriter.Write(jsonString);
                    }
                }
            }
            catch (Exception e)
            {
                throw new BacklogException(e.Message);
            }
        }
    }
}
