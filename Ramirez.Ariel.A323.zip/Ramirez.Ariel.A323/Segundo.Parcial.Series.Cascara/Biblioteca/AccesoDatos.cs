﻿using System.Data.SqlClient;

namespace Biblioteca
{
    public static class AccesoDatos
    {
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static AccesoDatos() 
        {
            conexion = new SqlConnection("Server=.;Database=20240701-SP;Trusted_Connection=True;");
            comando = new SqlCommand();
            comando. Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
        }

        public static void ActualizarSerie(Serie serie) 
        {
            try
            {
                conexion.Open();
                comando.CommandText = $"UPDATE dbo.series SET alumno = 'Ariel Ramirez' WHERE nombre = {serie.Nombre}";
                comando.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}"); //falta usar log
            }
            finally 
            { 
                conexion.Close();
            }
        }

        public static List<Serie> ObtenerBacklog() 
        { 
            List<Serie> list = new List<Serie>();
            
            try
            {
                conexion.Open();
                comando.CommandText = $"SELECT * FROM dbo.series";
                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        list.Add(new Serie(dataReader["genero"].ToString(), dataReader["nombre"].ToString()));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
            finally 
            { 
                conexion.Close();
            }
            return list;
        } 
    }
}
