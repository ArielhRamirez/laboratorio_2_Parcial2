using Biblioteca;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void DeberiaDevolverValorEntreCeroYCountDeLista()
        {
            //Arrange
            List<Serie> series = new List<Serie>();
            series.Add(new Serie());
            series.Add(new Serie());
            series.Add(new Serie());
            //Act
            int valorDevuelto = series.GenerarRandom();
            //Assert
            Assert.IsTrue(valorDevuelto >= 0 && valorDevuelto < series.Count);

        }
    }
}