using Biblioteca;

namespace Tests
{
    [TestClass]
    public class SerializacionTests
    {
        [TestMethod]
        public void DeberiaRetornarLaSerieSerializadaEnXmlAlEscritorio()
        {
            //Arrange
            List<Serie> serieList = new List<Serie>();
            serieList.Add(new Serie());
            Serializadora serializadora = new Serializadora();
            string rutadevolucion = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Prueba.xml");

            //Act
            serializadora.Guardar(serieList, rutadevolucion);

            //Assert
            Assert.IsTrue(File.Exists(rutadevolucion));

        }

        [TestMethod]
        public void DeberiaRetornarLaSerieSerializadaEnJsonAlEscritorio()
        {
            //Arrange
            List<Serie> serieList = new List<Serie>();
            serieList.Add(new Serie());
            Serializadora serializadora = new Serializadora();
            string rutadevolucion = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Prueba.json");

            //Act
            ((IGuardar<List<Serie>>)serializadora).Guardar(serieList, rutadevolucion);

            //Assert
            Assert.IsTrue(File.Exists(rutadevolucion));
        }
    }
}